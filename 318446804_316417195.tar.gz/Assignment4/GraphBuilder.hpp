#pragma once
#include <vector>
using namespace std;

class GraphBuilder {
public:
    static vector<vector<vector<int>>> constructAdj(int V,int& x );
};
