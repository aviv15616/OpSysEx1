#ifndef MAX_SUB_ARR_H
#define MAX_SUB_ARR_H

int max_sub_arr_n3(int* arr, int size);
int max_sub_arr_n2(int* arr, int size);
int max_sub_arr_n(int* arr, int size);
int* generate_random_array(int seed, int size);


#endif // MAX_SUB_ARR_H
